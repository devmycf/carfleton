var JoomlaShine = {};
JoomlaShine.jQuery = window.jQuery.noConflict();