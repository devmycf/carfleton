DROP TABLE IF EXISTS `#__jsn_poweradmin_history`;
DROP TABLE IF EXISTS `#__jsn_poweradmin_config`;
DROP TABLE IF EXISTS `#__jsn_poweradmin_menu_assets`;